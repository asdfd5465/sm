package bankwiser.bankpromotion.material.data.model

data class Category(
    val id: String,
    val name: String
)
