package bankwiser.bankpromotion.material.data.model

data class SubCategory(
    val id: String,
    val categoryId: String,
    val name: String
)
