package bankwiser.bankpromotion.material.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF4C51BF)
val PrimaryDark = Color(0xFF434190)
val GradientEnd = Color(0xFF6B46C1)
val TextPrimary = Color(0xFF2D3748)
val TextSecondary = Color(0xFF4A5568)
val BackgroundLight = Color(0xFFF7FAFC)
